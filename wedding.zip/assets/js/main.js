
// 디데이 계산
var dDay = new Date("April 23, 2022, 12:00:00").getTime();
// setInterval(function () {
//    var today = new Date().getTime();
//    var gap = dDay - today;
//    var day = Math.ceil(gap / (1000 * 60 * 60 * 24));

//    $('.calendar .d-day-wrap .highlight').html(day + "일");
// });

// 갤러리
lightGallery(document.getElementById('lightgallery'));